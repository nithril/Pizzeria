package com.example;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;

/**
 * Created on 19/04/2017
 *
 * @author labrot
 */
@RestController
public class MyController {

  private static final Logger LOG = LoggerFactory.getLogger(MyController.class);

  @PostConstruct
  public void foobar(){
    System.out.println("ok");
  }

  @GetMapping("/foo")
  public String foo() {
    LOG.info("foo!!!");
    return "ok";
  }
}
